using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using MaSV_MyStore.Models;
using MaSV_MyStore.Models.ViewModel;

namespace MaSV_MyStore.Controllers
{
    public class AccountController : Controller
    {
        private MyStoreEntities db = new MyStoreEntities();

        [HttpGet]
        public ActionResult Register()
        {
            return View(new RegisterVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(RegisterVM model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var existed = db.Users.Any(u => u.Username == model.Username);
            if (existed)
            {
                ModelState.AddModelError("Username", "Tên đăng nhập đã tồn tại.");
                return View(model);
            }

            var user = new User
            {
                Username = model.Username,
                Password = model.Password
            };

            var customer = new Customer
            {
                Username = model.Username,
                FullName = model.FullName,
                Phone = model.Phone,
                Email = model.Email,
                Address = model.Address
            };

            db.Users.Add(user);
            db.Customers.Add(customer);

            try
            {
                db.SaveChanges();
                TempData["Success"] = "Đăng ký tài khoản thành công. Vui lòng đăng nhập.";
                return RedirectToAction("Login", "Account");
            }
            catch (Exception)
            {
                ModelState.AddModelError("", "Không thể lưu tài khoản. Hãy kiểm tra tên cột và liên kết trong database.");
                return View(model);
            }
        }

        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginVM model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ReturnUrl = returnUrl;
                return View(model);
            }

            var user = db.Users.SingleOrDefault(u =>
                u.Username == model.Username && u.Password == model.Password);

            if (user == null)
            {
                ModelState.AddModelError("", "Tên đăng nhập hoặc mật khẩu không đúng.");
                ViewBag.ReturnUrl = returnUrl;
                return View(model);
            }

            Session["Username"] = user.Username;
            FormsAuthentication.SetAuthCookie(user.Username, model.RememberMe);

            if (!string.IsNullOrWhiteSpace(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        public ActionResult ProfileInfo()
        {
            ViewBag.Username = User.Identity.Name;
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
                db.Dispose();
            base.Dispose(disposing);
        }
    }
}
