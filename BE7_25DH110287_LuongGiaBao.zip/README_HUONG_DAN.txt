BAI ASP.NET MVC 5 - CUSTOMER SITE
Phạm vi: Đăng ký, đăng nhập, đăng xuất tài khoản khách hàng.

CÁCH ĐƯA VÀO VISUAL STUDIO
1. Giải nén file ZIP.
2. Mở solution ASP.NET MVC 5 hiện tại.
3. Thêm RegisterVM.cs và LoginVM.cs vào Models/ViewModel.
4. Thêm AccountController.cs vào Controllers.
5. Tạo Views/Account và thêm Register.cshtml, Login.cshtml.
6. Kiểm tra kết nối database MyStore trong Web.config.
7. Cấu hình Forms Authentication trong Web.config:
   <system.web>
     <authentication mode="Forms">
       <forms loginUrl="~/Account/Login" timeout="60" />
     </authentication>
   </system.web>
   Nếu đã có thẻ authentication thì chỉnh thẻ hiện tại, không tạo thẻ trùng.
8. Chạy ứng dụng và mở /Account/Register hoặc /Account/Login.

LƯU Ý TÍCH HỢP
- Đây là bộ code mẫu cho ASP.NET MVC 5 + Entity Framework 6.
- AccountController.cs giả định DbContext tên MyStoreEntities.
- Code giả định User có Username, Password; Customer có Username, FullName, Phone, Email, Address.
- Hãy đổi tên DbContext, bảng và thuộc tính nếu database của bạn sử dụng tên khác.
- Không tạo lại class User/Customer nếu Entity Framework đã sinh các class này từ EDMX.
- Mẫu này so sánh mật khẩu trực tiếp để phù hợp với cấu trúc bài tập cơ bản. Website thực tế cần lưu mật khẩu bằng cơ chế hash an toàn.
